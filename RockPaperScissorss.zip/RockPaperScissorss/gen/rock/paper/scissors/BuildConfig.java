/** Automatically generated file. DO NOT MODIFY */
package rock.paper.scissors;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}